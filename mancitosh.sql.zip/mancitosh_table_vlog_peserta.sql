
-- --------------------------------------------------------

--
-- Table structure for table `vlog_peserta`
--

CREATE TABLE `vlog_peserta` (
  `id` int(11) NOT NULL,
  `telepon` char(32) NOT NULL,
  `ketua` char(255) NOT NULL,
  `sekolah` char(255) NOT NULL,
  `anggota` char(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
