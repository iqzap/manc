
-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE `faq` (
  `id` int(11) NOT NULL,
  `tanya` char(255) NOT NULL,
  `jawab` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
