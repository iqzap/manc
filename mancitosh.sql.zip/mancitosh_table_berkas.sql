
-- --------------------------------------------------------

--
-- Table structure for table `berkas`
--

CREATE TABLE `berkas` (
  `id` int(11) NOT NULL,
  `kategori` enum('robot','vlog') NOT NULL,
  `telepon` char(32) NOT NULL,
  `judul` char(255) NOT NULL,
  `deskripsi` text NOT NULL,
  `video` char(255) NOT NULL,
  `cover` char(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
