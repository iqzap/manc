
-- --------------------------------------------------------

--
-- Table structure for table `narahubung`
--

CREATE TABLE `narahubung` (
  `id` int(11) NOT NULL,
  `bidang` enum('robot','vlog') NOT NULL,
  `nama` char(40) NOT NULL,
  `ig` char(24) NOT NULL,
  `wa` char(24) NOT NULL,
  `foto` char(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `narahubung`
--

INSERT INTO `narahubung` (`id`, `bidang`, `nama`, `ig`, `wa`, `foto`) VALUES
(1, 'robot', 'Gempar Yanuar', 'gmpr.yanuar_', '+62 857-3026-6687', 'ava-robot-siswa.jpg'),
(2, 'robot', 'Widya', 'man1ponorogo', '+62 812-5902-6110', 'ava.jpg'),
(3, 'vlog', 'Roofiif Alria', 'roofiifalria', '+62 812-3152-4296', 'ava-vlog-siswa.jpg'),
(4, 'vlog', 'Nur Iswahyudi', 'iswahyudi.nur', '+62 857-4969-9665', 'ava-vlog-guru.jpg');
